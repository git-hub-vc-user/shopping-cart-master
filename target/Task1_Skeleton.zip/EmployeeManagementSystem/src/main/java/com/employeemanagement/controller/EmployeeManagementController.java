/**
 * 
 */
package com.employeemanagement.controller;

import java.util.Hashtable;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.employeemanagement.exception.EmployeeManagementException;
import com.employeemanagement.model.Skills;

public class EmployeeManagementController {

	/**
	 * @param employeeName
	 * @return List
	 * @throws EmployeeManagementException
	 */
	public List<Skills> getListOfSkillsetOfAnEmployee(@PathVariable("employeeName") String employeeName) {
		return null;
	}

	/**
	 * @return Hashtable
	 */
	public Hashtable<String, Skills> getListOfAllSkills() {
		return null;
	}

}
