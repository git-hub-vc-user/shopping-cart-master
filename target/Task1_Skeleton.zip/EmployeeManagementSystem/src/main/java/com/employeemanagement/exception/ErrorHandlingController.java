/**
 * 
 */
package com.employeemanagement.exception;

import org.springframework.http.ResponseEntity;

public class ErrorHandlingController {

	/**
	 * @param e
	 * @return ResponseEntity
	 */

	public final ResponseEntity<ExceptionResponse> somethingWentWrong(Exception e) {
		return null;
	}

}
